/**
 * 
 */
interface Scene {
    inAnimate();
    outAnimate();
}