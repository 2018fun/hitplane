/**
 * 
 */
class PlaneGrid {
    // private gridView: egret.Bitmap;

    // constructor() {

    // }

    // private initView() {

    // }

    // private 

}