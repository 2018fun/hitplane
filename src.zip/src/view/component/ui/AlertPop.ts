/**
 * 
 */
class AlertPop extends egret.Sprite {

    constructor() {
        super();
    }
}