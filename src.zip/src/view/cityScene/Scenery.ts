/**
 * 风景
 */
class Scenery extends egret.Bitmap {
    constructor() {
        super();
    }
    
    public update(texture) {
        this.texture = texture;
    }
}