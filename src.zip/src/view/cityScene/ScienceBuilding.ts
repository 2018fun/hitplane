/**
 * 科学院
 */
class Science extends egret.Bitmap {
    constructor() {
        super();
    }

    public update(texture) {
        this.texture = texture;
    }
}