/**
 * 
 */
class RankButtom extends egret.Sprite {
    constructor() {
        super();
        this.initView();
    }

    private bgView: egret.Bitmap;

    private initView() {


    }

    private updateView() {

    }

}