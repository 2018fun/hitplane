/**
 * 银行
 */
class Bank extends egret.Bitmap {
    constructor() {
        super();
    }

    public update(texture) {
        this.texture = texture;
    }
}