/**
 * 统计
 * 我的打击
 * 我使用过的地图等
 */
class MineScene extends egret.Sprite {
    
    private level;
    private gold;
    private gas;
    private hit;
    private win;
    

    constructor() {
        super();
    }



}