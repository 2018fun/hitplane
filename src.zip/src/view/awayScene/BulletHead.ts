/**
 * 子弹头部
 */
class BulletHead extends egret.Sprite {

    private bulletName;
    private bulletType;
    private playerName;

    constructor() {
        super();
        this.initView();
    }

    private initView() {

    }

    private updateView() {

    }

    private setName(name) {
        this.playerName = name;
    }

}