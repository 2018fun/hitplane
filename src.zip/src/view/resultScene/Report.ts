/**
 * 报告
 */
class Report extends egret.Sprite {
    constructor() {
        super();
    }
}
