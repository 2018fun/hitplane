class HeadData {
    public head;
    public direction

    constructor(data) {
        this.head = data.head;
        this.direction = data.direction;
    }
}