/**
 * 
 */
module ResourceEnum {
    export const GOLD = "gold";
    export const GAS = "gas";
}