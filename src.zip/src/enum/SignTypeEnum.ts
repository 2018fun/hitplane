/**
 * 
 */
class SignTypeEnum {
    /**
     * 未做标记
     */
    static UNSIGN: number = -1;
    /**
     *  格子空
     */
    static MISS: number = 0;
    /**
      *  格子中
      */
    static BODY: number = 1;
    /**
      *  格子头
      */
    static HEAD: number = 2;
}