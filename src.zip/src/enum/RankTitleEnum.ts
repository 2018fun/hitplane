/**
 * 排行头衔
 */
module RankTitleEnum {
    // 倔强青铜、秩序白银、荣耀黄金、尊贵铂金、永恒钻石、至尊星耀、最强王者和荣耀王者
    export const King = "荣耀王者";

    
}