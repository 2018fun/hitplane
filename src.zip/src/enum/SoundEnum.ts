
module SoundEnum {
    export const BACKGROUND_MP3 = "background_mp3";
    
    export const DROP_MP3 = "drop_mp3";

    export const FAIL_MP3 = "fail_mp3";

    export const HEAD_MP3 = "head_mp3";

    export const HIT_MP3 = "hit_mp3";

    export const MISS_MP3 = "miss_mp3";

    export const SUCCESS_MP3 = "success_mp3";

}