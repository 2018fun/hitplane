/**
 * 
 */
module RewardTitleEnum {
    export const KILLING_SPREE = 3;
    export const DOMANATING = 4; //主宰比赛
    export const MEGA_KILL = 5 //杀人如麻
    export const UNSTOPPABLE = 6 //无人能挡
    export const WICKED_SICK = 7//变态杀戮
    export const MONSTER_KILL = 8// 如同妖怪一般
    export const GOD_LIKE = 9//如同神一般
    export const HOLY_SHIT = 10//超越神了
    export const DOUBLE_KILL = 2//双杀
    export const TRIPLE_KILL = 3//三杀
    export const ULTRAKILL = 4// 疯狂杀戮（四杀）
    export const RAMPAGE = 5//暴走（五杀）
}