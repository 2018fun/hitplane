module SceneEnum {
    export const AWAY_SCENE = 0;
    export const CITY_SCENE = 1;
    export const PLACING_SCENE = 2;
    export const RESULT_SCENE = 3;
}