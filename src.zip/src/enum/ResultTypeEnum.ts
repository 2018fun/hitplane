/**
 * 
 */

module ResultTypeEnum {
    export const WIN = 1;
    export const FAIL = 2;
    export const GIVE_UP = 3;
}