module AIConst {
    export const LEFT_UP=0;
    export const RIGHT_UP = 1;
    export const RIGHT_DOWN = 2;
    export const LEFT_DOWN =3;
    export const CENTER = 4;

    export var TEST_POSITION = [];
    TEST_POSITION[LEFT_UP] = [30, 40, 20]
}