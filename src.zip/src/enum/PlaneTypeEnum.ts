/**
 * 
 */
class PlaneTypeEnum {
    /**
     * 战斗机
     */
    static FIGHTER
    /**
     * 轰炸机
     */
    /**
     * 歼击机
     */
}