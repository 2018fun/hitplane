/**
 * 
 */
class GridEvent extends egret.EventDispatcher {

    public static GRID_EVENT_TYPE_TOUCHED

    constructor() {

        super();
    }
}